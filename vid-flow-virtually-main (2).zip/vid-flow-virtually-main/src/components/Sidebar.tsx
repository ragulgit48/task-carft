import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { 
  MessageSquare, 
  FileText, 
  Users, 
  Settings, 
  Plus,
  File,
  Image,
  Download,
  Clock
} from "lucide-react";
import { useState } from "react";

const Sidebar = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'files' | 'participants'>('chat');

  const messages = [
    { id: 1, sender: "Alex", message: "Hey everyone! Ready for the demo?", time: "2:34 PM" },
    { id: 2, sender: "Sarah", message: "Yes! I've prepared the slides", time: "2:35 PM" },
    { id: 3, sender: "Mike", message: "Sounds good. I'll share my screen in a moment", time: "2:36 PM" },
  ];

  const files = [
    { id: 1, name: "Project_Presentation.pdf", size: "2.4 MB", type: "pdf", shared: "Alex" },
    { id: 2, name: "Design_Mockups.figma", size: "15.7 MB", type: "design", shared: "Sarah" },
    { id: 3, name: "meeting_notes.txt", size: "0.3 MB", type: "text", shared: "Mike" },
  ];

  const participants = [
    { id: 1, name: "Alex Johnson", status: "host", isOnline: true },
    { id: 2, name: "Sarah Chen", status: "participant", isOnline: true },
    { id: 3, name: "Mike Rodriguez", status: "participant", isOnline: true },
    { id: 4, name: "Emma Thompson", status: "participant", isOnline: false },
  ];

  return (
    <div className="w-80 bg-card border-l border-border flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <h2 className="text-lg font-semibold">Team Meeting</h2>
        <p className="text-sm text-muted-foreground">4 participants</p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border">
        <Button
          variant={activeTab === 'chat' ? 'default' : 'ghost'}
          size="sm"
          className="flex-1 rounded-none"
          onClick={() => setActiveTab('chat')}
        >
          <MessageSquare className="w-4 h-4 mr-2" />
          Chat
        </Button>
        <Button
          variant={activeTab === 'files' ? 'default' : 'ghost'}
          size="sm"
          className="flex-1 rounded-none"
          onClick={() => setActiveTab('files')}
        >
          <FileText className="w-4 h-4 mr-2" />
          Files
        </Button>
        <Button
          variant={activeTab === 'participants' ? 'default' : 'ghost'}
          size="sm"
          className="flex-1 rounded-none"
          onClick={() => setActiveTab('participants')}
        >
          <Users className="w-4 h-4 mr-2" />
          People
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'chat' && (
          <div className="h-full flex flex-col">
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{message.sender}</span>
                      <span className="text-xs text-muted-foreground">{message.time}</span>
                    </div>
                    <Card className="p-3 bg-secondary">
                      <p className="text-sm">{message.message}</p>
                    </Card>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="p-4 border-t border-border">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Type a message..."
                  className="flex-1 px-3 py-2 bg-input border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />
                <Button size="sm">Send</Button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'files' && (
          <div className="h-full">
            <div className="p-4 border-b border-border">
              <Button size="sm" className="w-full">
                <Plus className="w-4 h-4 mr-2" />
                Share File
              </Button>
            </div>
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-3">
                {files.map((file) => (
                  <Card key={file.id} className="p-3 hover:bg-secondary/50 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center">
                        {file.type === 'pdf' && <File className="w-4 h-4 text-primary" />}
                        {file.type === 'design' && <Image className="w-4 h-4 text-primary" />}
                        {file.type === 'text' && <FileText className="w-4 h-4 text-primary" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm truncate">{file.name}</h4>
                        <p className="text-xs text-muted-foreground">
                          {file.size} • Shared by {file.shared}
                        </p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>
        )}

        {activeTab === 'participants' && (
          <ScrollArea className="h-full p-4">
            <div className="space-y-3">
              {participants.map((participant) => (
                <Card key={participant.id} className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center text-sm font-medium">
                        {participant.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-card ${
                        participant.isOnline ? 'bg-green-500' : 'bg-muted-foreground'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{participant.name}</h4>
                      <div className="flex items-center gap-2">
                        <Badge variant={participant.status === 'host' ? 'default' : 'secondary'} className="text-xs">
                          {participant.status}
                        </Badge>
                        {!participant.isOnline && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="w-3 h-3" />
                            Away
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </ScrollArea>
        )}
      </div>

      {/* Settings */}
      <div className="p-4 border-t border-border">
        <Button variant="ghost" size="sm" className="w-full justify-start">
          <Settings className="w-4 h-4 mr-2" />
          Settings
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;