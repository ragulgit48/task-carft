import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Video, VideoOff, Mic, MicOff, Phone, PhoneOff, Monitor, Users, MessageSquare } from "lucide-react";
import { useState } from "react";

const VideoCall = () => {
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);

  const participants = [
    { id: 1, name: "Alex Johnson", isVideo: true, isMuted: false },
    { id: 2, name: "Sarah Chen", isVideo: true, isMuted: true },
    { id: 3, name: "Mike Rodriguez", isVideo: false, isMuted: false },
    { id: 4, name: "Emma Thompson", isVideo: true, isMuted: false },
  ];

  return (
    <div className="flex-1 bg-video-bg relative overflow-hidden">
      {/* Main video area */}
      <div className="h-full grid grid-cols-2 gap-4 p-4">
        {participants.map((participant) => (
          <Card
            key={participant.id}
            className="relative bg-gradient-card border-border/50 backdrop-blur-sm overflow-hidden group hover:scale-[1.02] transition-all duration-300"
            style={{ boxShadow: 'var(--shadow-video)' }}
          >
            <div className="aspect-video bg-video-bg rounded-lg overflow-hidden relative">
              {participant.isVideo ? (
                <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-gradient-primary flex items-center justify-center text-2xl font-bold">
                    {participant.name.split(' ').map(n => n[0]).join('')}
                  </div>
                </div>
              ) : (
                <div className="w-full h-full bg-muted flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center">
                    <VideoOff className="w-8 h-8 text-muted-foreground" />
                  </div>
                </div>
              )}
              
              {/* Participant info overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-glass backdrop-blur-md p-3">
                <div className="flex items-center justify-between">
                  <span className="text-foreground font-medium">{participant.name}</span>
                  <div className="flex items-center gap-2">
                    {participant.isMuted && (
                      <div className="w-6 h-6 rounded-full bg-destructive/20 flex items-center justify-center">
                        <MicOff className="w-3 h-3 text-destructive" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Bottom controls */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2">
        <div className="bg-gradient-glass backdrop-blur-xl rounded-2xl p-4 border border-border/50">
          <div className="flex items-center gap-4">
            <Button
              variant={isCameraOn ? "secondary" : "destructive"}
              size="lg"
              className="rounded-full w-12 h-12"
              onClick={() => setIsCameraOn(!isCameraOn)}
            >
              {isCameraOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
            </Button>
            
            <Button
              variant={isMicOn ? "secondary" : "destructive"}
              size="lg"
              className="rounded-full w-12 h-12"
              onClick={() => setIsMicOn(!isMicOn)}
            >
              {isMicOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
            </Button>

            <Button
              variant={isScreenSharing ? "default" : "secondary"}
              size="lg"
              className="rounded-full w-12 h-12"
              onClick={() => setIsScreenSharing(!isScreenSharing)}
            >
              <Monitor className="w-5 h-5" />
            </Button>

            <Button
              variant="secondary"
              size="lg"
              className="rounded-full w-12 h-12"
            >
              <Users className="w-5 h-5" />
            </Button>

            <Button
              variant="secondary"
              size="lg"
              className="rounded-full w-12 h-12"
            >
              <MessageSquare className="w-5 h-5" />
            </Button>

            <Button
              variant="destructive"
              size="lg"
              className="rounded-full w-12 h-12 ml-4"
            >
              <PhoneOff className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoCall;