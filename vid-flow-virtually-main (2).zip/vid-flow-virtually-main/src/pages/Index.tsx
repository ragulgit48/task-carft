import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import VideoCall from "@/components/VideoCall";
import Sidebar from "@/components/Sidebar";
import Whiteboard from "@/components/Whiteboard";
import { 
  Video, 
  MessageSquare, 
  FileText, 
  Users, 
  Calendar,
  Settings,
  PenTool
} from "lucide-react";

const Index = () => {
  const [activeView, setActiveView] = useState<'video' | 'whiteboard'>('video');
  const [showSidebar, setShowSidebar] = useState(true);

  return (
    <div className="min-h-screen bg-background flex">
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                CommLink
              </h1>
              <div className="flex items-center gap-2">
                <Button
                  variant={activeView === 'video' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('video')}
                >
                  <Video className="w-4 h-4 mr-2" />
                  Video Call
                </Button>
                <Button
                  variant={activeView === 'whiteboard' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('whiteboard')}
                >
                  <PenTool className="w-4 h-4 mr-2" />
                  Whiteboard
                </Button>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm">
                <Calendar className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSidebar(!showSidebar)}
              >
                <MessageSquare className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Main View */}
        <div className="flex-1 flex">
          <div className="flex-1">
            {activeView === 'video' ? <VideoCall /> : <Whiteboard />}
          </div>
          
          {showSidebar && <Sidebar />}
        </div>
      </div>
    </div>
  );
};

export default Index;