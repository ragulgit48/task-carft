import { ProjectHeader } from "@/components/project-header"
import { ProjectBoard } from "@/components/project-board"
import { Button } from "@/components/ui/button"
import { Plus, Search, Bell, User } from "lucide-react"
import { Input } from "@/components/ui/input"

// Mock data for demonstration
const mockProject = {
  projectName: "Website Redesign Project",
  description: "Complete redesign of our company website with modern UI/UX principles and improved performance.",
  members: [
    { name: "Alice Johnson", initials: "AJ", avatar: "/api/placeholder/32/32" },
    { name: "Bob Smith", initials: "BS", avatar: "/api/placeholder/32/32" },
    { name: "Carol Davis", initials: "CD", avatar: "/api/placeholder/32/32" },
    { name: "David Wilson", initials: "DW", avatar: "/api/placeholder/32/32" },
    { name: "Emma Brown", initials: "EB", avatar: "/api/placeholder/32/32" },
  ],
  totalTasks: 24,
  completedTasks: 8
}

const mockColumns = [
  {
    id: "todo",
    title: "To Do",
    tasks: [
      {
        title: "Design system documentation",
        description: "Create comprehensive documentation for the new design system including components, colors, and typography guidelines.",
        status: "todo" as const,
        assignee: { name: "Alice Johnson", initials: "AJ", avatar: "/api/placeholder/32/32" },
        dueDate: "Dec 15",
        commentsCount: 3,
        priority: "high" as const
      },
      {
        title: "Mobile navigation prototype",
        description: "Build interactive prototype for mobile navigation patterns.",
        status: "todo" as const,
        assignee: { name: "Bob Smith", initials: "BS", avatar: "/api/placeholder/32/32" },
        dueDate: "Dec 18",
        attachmentsCount: 2,
        priority: "medium" as const
      },
      {
        title: "User testing interviews",
        description: "Conduct user interviews to validate design decisions.",
        status: "todo" as const,
        assignee: { name: "Carol Davis", initials: "CD", avatar: "/api/placeholder/32/32" },
        dueDate: "Dec 22",
        commentsCount: 1,
        priority: "low" as const
      }
    ]
  },
  {
    id: "in-progress", 
    title: "In Progress",
    tasks: [
      {
        title: "Homepage hero section",
        description: "Implement the new hero section with animations and responsive design.",
        status: "in-progress" as const,
        assignee: { name: "David Wilson", initials: "DW", avatar: "/api/placeholder/32/32" },
        dueDate: "Dec 12",
        commentsCount: 5,
        attachmentsCount: 3,
        priority: "high" as const
      },
      {
        title: "Performance optimization", 
        description: "Optimize images and implement lazy loading for better performance.",
        status: "in-progress" as const,
        assignee: { name: "Emma Brown", initials: "EB", avatar: "/api/placeholder/32/32" },
        dueDate: "Dec 14",
        commentsCount: 2,
        priority: "medium" as const
      }
    ]
  },
  {
    id: "review",
    title: "In Review", 
    tasks: [
      {
        title: "Color palette finalization",
        description: "Review and finalize the color palette for brand consistency.",
        status: "review" as const,
        assignee: { name: "Alice Johnson", initials: "AJ", avatar: "/api/placeholder/32/32" },
        dueDate: "Dec 10",
        commentsCount: 8,
        priority: "high" as const
      }
    ]
  },
  {
    id: "done",
    title: "Done",
    tasks: [
      {
        title: "Wireframe creation",
        description: "Create detailed wireframes for all main pages.",
        status: "done" as const,
        assignee: { name: "Bob Smith", initials: "BS", avatar: "/api/placeholder/32/32" },
        commentsCount: 4,
        priority: "medium" as const
      },
      {
        title: "Brand guidelines update",
        status: "done" as const,
        assignee: { name: "Carol Davis", initials: "CD", avatar: "/api/placeholder/32/32" },
        commentsCount: 2,
        attachmentsCount: 1,
        priority: "low" as const
      }
    ]
  }
]

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b bg-white/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h2 className="text-xl font-bold bg-gradient-hero bg-clip-text text-transparent">
                  ProjectFlow
                </h2>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search tasks, projects..."
                  className="pl-10 w-64"
                />
              </div>
              
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              
              <Button size="sm" className="bg-gradient-primary">
                <Plus className="h-4 w-4 mr-2" />
                New Project
              </Button>
              
              <Button variant="outline" size="sm">
                <User className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ProjectHeader {...mockProject} />
        
        <div className="mt-8">
          <ProjectBoard columns={mockColumns} />
        </div>
      </main>
    </div>
  );
};

export default Index;
