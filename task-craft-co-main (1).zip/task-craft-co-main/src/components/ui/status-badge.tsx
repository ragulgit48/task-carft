import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const statusBadgeVariants = cva(
  "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium transition-smooth",
  {
    variants: {
      variant: {
        todo: "bg-muted text-muted-foreground",
        "in-progress": "bg-info/10 text-info border border-info/20",
        review: "bg-warning/10 text-warning border border-warning/20",
        done: "bg-success/10 text-success border border-success/20",
        blocked: "bg-destructive/10 text-destructive border border-destructive/20"
      },
      size: {
        sm: "px-2 py-0.5 text-xs",
        md: "px-2.5 py-1 text-sm",
        lg: "px-3 py-1.5 text-sm"
      }
    },
    defaultVariants: {
      variant: "todo",
      size: "sm"
    }
  }
)

export interface StatusBadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof statusBadgeVariants> {}

function StatusBadge({ className, variant, size, ...props }: StatusBadgeProps) {
  return (
    <div className={cn(statusBadgeVariants({ variant, size }), className)} {...props} />
  )
}

export { StatusBadge, statusBadgeVariants }