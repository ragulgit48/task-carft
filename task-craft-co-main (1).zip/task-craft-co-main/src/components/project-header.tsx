import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Settings, Share2, Filter, Users, Calendar } from "lucide-react"

interface ProjectHeaderProps {
  projectName: string
  description?: string
  members?: Array<{
    name: string
    avatar?: string
    initials: string
  }>
  totalTasks?: number
  completedTasks?: number
}

export function ProjectHeader({ 
  projectName, 
  description, 
  members = [],
  totalTasks = 0,
  completedTasks = 0
}: ProjectHeaderProps) {
  const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">{projectName}</h1>
          {description && (
            <p className="text-muted-foreground max-w-2xl">{description}</p>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>
      
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-muted-foreground" />
          <div className="flex -space-x-2">
            {members.slice(0, 4).map((member, index) => (
              <Avatar key={index} className="h-8 w-8 border-2 border-background">
                <AvatarImage src={member.avatar} alt={member.name} />
                <AvatarFallback className="text-xs">{member.initials}</AvatarFallback>
              </Avatar>
            ))}
            {members.length > 4 && (
              <div className="h-8 w-8 rounded-full bg-muted border-2 border-background flex items-center justify-center">
                <span className="text-xs text-muted-foreground">+{members.length - 4}</span>
              </div>
            )}
          </div>
          <span className="text-sm text-muted-foreground">{members.length} members</span>
        </div>
        
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <Badge variant="outline">{progress}% Complete</Badge>
          <span className="text-sm text-muted-foreground">
            {completedTasks} of {totalTasks} tasks
          </span>
        </div>
      </div>
    </div>
  )
}