import { Card } from "@/components/ui/card"
import { StatusBadge } from "@/components/ui/status-badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Calendar, MessageCircle, Paperclip } from "lucide-react"
import { cn } from "@/lib/utils"

export interface TaskCardProps {
  title: string
  description?: string
  status: "todo" | "in-progress" | "review" | "done" | "blocked"
  assignee?: {
    name: string
    avatar?: string
    initials: string
  }
  dueDate?: string
  commentsCount?: number
  attachmentsCount?: number
  priority?: "low" | "medium" | "high"
  className?: string
}

export function TaskCard({
  title,
  description,
  status,
  assignee,
  dueDate,
  commentsCount = 0,
  attachmentsCount = 0,
  priority = "medium",
  className
}: TaskCardProps) {
  const priorityColors = {
    low: "border-l-success",
    medium: "border-l-warning", 
    high: "border-l-destructive"
  }

  return (
    <Card className={cn(
      "p-4 cursor-pointer hover:shadow-medium transition-smooth border-l-4",
      priorityColors[priority],
      className
    )}>
      <div className="space-y-3">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-sm leading-relaxed">{title}</h3>
          <StatusBadge variant={status} size="sm" />
        </div>
        
        {description && (
          <p className="text-sm text-muted-foreground line-clamp-2">{description}</p>
        )}
        
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-3">
            {dueDate && (
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                <span>{dueDate}</span>
              </div>
            )}
            
            {commentsCount > 0 && (
              <div className="flex items-center gap-1">
                <MessageCircle className="h-3 w-3" />
                <span>{commentsCount}</span>
              </div>
            )}
            
            {attachmentsCount > 0 && (
              <div className="flex items-center gap-1">
                <Paperclip className="h-3 w-3" />
                <span>{attachmentsCount}</span>
              </div>
            )}
          </div>
          
          {assignee && (
            <Avatar className="h-6 w-6">
              <AvatarImage src={assignee.avatar} alt={assignee.name} />
              <AvatarFallback className="text-xs">{assignee.initials}</AvatarFallback>
            </Avatar>
          )}
        </div>
      </div>
    </Card>
  )
}