import { TaskCard, TaskCardProps } from "@/components/task-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

interface BoardColumn {
  id: string
  title: string
  tasks: TaskCardProps[]
  color?: string
}

interface ProjectBoardProps {
  columns: BoardColumn[]
}

export function ProjectBoard({ columns }: ProjectBoardProps) {
  return (
    <div className="flex gap-6 overflow-x-auto pb-6">
      {columns.map((column) => (
        <div key={column.id} className="flex-shrink-0 w-80">
          <Card className="bg-secondary/30">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  {column.title}
                  <span className="ml-2 bg-muted text-muted-foreground rounded-full px-2 py-0.5 text-xs">
                    {column.tasks.length}
                  </span>
                </CardTitle>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {column.tasks.map((task, index) => (
                <TaskCard key={index} {...task} />
              ))}
              
              <Button 
                variant="ghost" 
                className="w-full justify-start text-muted-foreground hover:text-foreground border-2 border-dashed border-muted hover:border-primary/20"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add a task
              </Button>
            </CardContent>
          </Card>
        </div>
      ))}
    </div>
  )
}